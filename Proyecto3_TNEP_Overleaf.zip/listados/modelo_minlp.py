def construir_minlp(sis, env, theta_max=None, entero=True):
    """Modelo MINLP con el producto bilineal n_ij * B_ij * (theta_i - theta_j)."""
    theta_max = float(theta_max or sis.p("theta_max_rad", np.pi))
    m = gp.Model("TNEP_MINLP_bilineal", env=env)

    theta = m.addVars(sis.nb, lb=-theta_max, ub=theta_max, name="theta")
    theta[sis.ref].lb = theta[sis.ref].ub = 0.0
    tipo_n = GRB.INTEGER if entero else GRB.CONTINUOUS
    n = m.addVars(sis.nc, lb=0, ub=sis.c_nmax.astype(float).tolist(), vtype=tipo_n, name="n")
    # apertura angular de cada corredor y flujo total del corredor
    dth = m.addVars(sis.nc, lb=-2 * theta_max, ub=2 * theta_max, name="dtheta")
    p_c = m.addVars(sis.nc, lb=(-sis.c_nmax * sis.c_pmax).tolist(),
                    ub=(sis.c_nmax * sis.c_pmax).tolist(), name="Pij")
    # flujos de la red existente (27) con su limite (29) como cota de la variable
    p_e = m.addVars(sis.nl, lb=(-sis.l_n0 * sis.l_pmax).tolist(),
                    ub=(sis.l_n0 * sis.l_pmax).tolist(), name="Pa")

    for l in range(sis.nl):                                              # (27)
        m.addConstr(p_e[l] == sis.l_n0[l] / sis.l_x[l] * (theta[sis.l_de[l]] - theta[sis.l_a[l]]),
                    name=f"flujo_existente_{sis.etiqueta_linea(l)}_{l}")
    for k in range(sis.nc):
        cid = sis.c_id[k]
        m.addConstr(dth[k] == theta[sis.c_de[k]] - theta[sis.c_a[k]], name=f"apertura_{cid}")
        m.addConstr(p_c[k] == (1.0 / sis.c_x[k]) * n[k] * dth[k], name=f"bilineal_{cid}")  # (28)
        m.addConstr(p_c[k] <= sis.c_pmax[k] * n[k], name=f"cap_sup_{cid}")                 # (30)
        m.addConstr(p_c[k] >= -sis.c_pmax[k] * n[k], name=f"cap_inf_{cid}")

    # (25) balance nodal  B^a(n) theta = PG - PL  escrito con flujos
    salida = [gp.LinExpr() for _ in range(sis.nb)]
    for l in range(sis.nl):
        salida[sis.l_de[l]] += p_e[l]
        salida[sis.l_a[l]] -= p_e[l]
    for k in range(sis.nc):
        salida[sis.c_de[k]] += p_c[k]
        salida[sis.c_a[k]] -= p_c[k]
    for i in range(sis.nb):
        m.addConstr(salida[i] == sis.pg[i] - sis.pl[i], name=f"balance_{sis.barras[i]}")

    m.setObjective(gp.quicksum(sis.c_costo[k] * n[k] for k in range(sis.nc)), GRB.MINIMIZE)  # (24)
    m.Params.NonConvex = 2              # B&B espacial global para la restriccion bilineal
    return m, dict(theta=theta, n=n, dth=dth, p_c=p_c, p_e=p_e, theta_max=theta_max)
