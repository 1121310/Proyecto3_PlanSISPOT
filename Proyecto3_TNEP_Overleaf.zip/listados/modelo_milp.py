def construir_milp(sis, env, M):
    """Modelo M(0-1)LP disyuntivo de Villasana (1984) con constantes big-M `M[k]`."""
    m = gp.Model("TNEP_MILP_bigM_Villasana", env=env)
    theta = m.addVars(sis.nb, lb=-GRB.INFINITY, ub=GRB.INFINITY, name="theta")
    theta[sis.ref].lb = theta[sis.ref].ub = 0.0
    idx = [(k, j) for k in range(sis.nc) for j in range(1, int(sis.c_nmax[k]) + 1)]
    w = m.addVars(idx, vtype=GRB.BINARY, name="w")
    dth = m.addVars(idx, lb=-GRB.INFINITY, ub=GRB.INFINITY, name="dtheta")
    # (15),(17) red existente: flujo con su limite como cota de la variable
    p_e = m.addVars(sis.nl, lb=(-sis.l_n0 * sis.l_pmax).tolist(),
                    ub=(sis.l_n0 * sis.l_pmax).tolist(), name="Pa")
    for l in range(sis.nl):
        m.addConstr(p_e[l] == sis.l_n0[l] / sis.l_x[l] * (theta[sis.l_de[l]] - theta[sis.l_a[l]]),
                    name=f"flujo_existente_{sis.etiqueta_linea(l)}_{l}")

    salida = [gp.LinExpr() for _ in range(sis.nb)]
    for l in range(sis.nl):
        salida[sis.l_de[l]] += p_e[l]
        salida[sis.l_a[l]] -= p_e[l]

    for c in range(sis.nc):
        cid, b = sis.c_id[c], 1.0 / sis.c_x[c]
        ks = range(1, int(sis.c_nmax[c]) + 1)
        if not ks:
            continue
        for k in ks:
            flujo = k * b * dth[c, k]                                         # (18)
            m.addConstr(flujo <= k * sis.c_pmax[c] * w[c, k], name=f"cap_sup_{cid}_{k}")   # (16)
            m.addConstr(flujo >= -k * sis.c_pmax[c] * w[c, k], name=f"cap_inf_{cid}_{k}")
            salida[sis.c_de[c]] += flujo
            salida[sis.c_a[c]] -= flujo
        suma_w = gp.quicksum(w[c, k] for k in ks)
        holgura = theta[sis.c_de[c]] - theta[sis.c_a[c]] - gp.quicksum(dth[c, k] for k in ks)
        m.addConstr(holgura <= M[c] * (1 - suma_w), name=f"bigM_sup_{cid}")         # (19)
        m.addConstr(holgura >= M[c] * (suma_w - 1), name=f"bigM_inf_{cid}")
        m.addConstr(suma_w <= 1, name=f"unicidad_{cid}")                           # (20)

    for i in range(sis.nb):                                                         # (14)
        m.addConstr(salida[i] == sis.pg[i] - sis.pl[i], name=f"balance_{sis.barras[i]}")

    m.setObjective(gp.quicksum(k * sis.c_costo[c] * w[c, k] for c, k in idx), GRB.MINIMIZE)  # (13)
    return m, dict(theta=theta, w=w, dth=dth, p_e=p_e, idx=idx)
