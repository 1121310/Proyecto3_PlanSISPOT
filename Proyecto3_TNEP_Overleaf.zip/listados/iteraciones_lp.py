def lp_iterativo(sis, criterio=None, max_iter=None, env=None, verbose=True, exportar=None):
    """Procedimiento iterativo: resolver LP, agregar una linea, repetir."""
    criterio = (criterio or sis.p("criterio_lp", "flujo")).lower()
    tol = float(sis.p("tolerancia", 1e-6))
    max_iter = max_iter or int(sis.c_nmax.sum()) + 1
    n_adic = np.zeros(sis.nc, dtype=int)
    historia = []
    t0 = time.perf_counter()
    estado_final = "OPTIMO"

    for it in range(1, max_iter + 1):
        m, v = construir_lp(sis, n_adic, env)
        m.Params.Method = 0           # simplex primal (como el Solver de Excel)
        m.optimize()
        if exportar and it == 1:
            exportar_modelo(m, exportar)
        if m.Status != GRB.OPTIMAL:
            estado_final = nombre_estado(m.Status)
            historia.append(dict(iteracion=it, estado=estado_final, n=n_adic.tolist()))
            break
        p_mas = np.array([v["p_mas"][k].X for k in range(sis.nc)])
        p_menos = np.array([v["p_menos"][k].X for k in range(sis.nc)])
        theta = np.array([v["theta"][i].X for i in range(sis.nb)])
        sobrecarga = p_mas + p_menos                     # pu
        lineas_eq = sobrecarga / sis.c_pmax              # lineas equivalentes
        registro = dict(
            iteracion=it, estado="OPTIMO", objetivo=m.ObjVal, n=n_adic.tolist(),
            theta=theta.tolist(), P_mas=p_mas.tolist(), P_menos=p_menos.tolist(),
            sobrecarga_MW=(sobrecarga * sis.sbase).tolist(), lineas_equivalentes=lineas_eq.tolist(),
            flujos_MW={f"{r['etiqueta']}({r['tipo'][0]})": v["pf"][e].X * sis.sbase
                       for e, r in enumerate(v["ramas"])},
            estadisticas=estadisticas(m))
        if lineas_eq.max() <= tol:
            registro["corredor_elegido"] = None
            historia.append(registro)
            break
        if criterio == "costo":
            puntaje = sis.c_costo * lineas_eq
        else:
            puntaje = lineas_eq
        k_sel = int(np.argmax(puntaje))
        registro["corredor_elegido"] = sis.c_id[k_sel]
        historia.append(registro)
        if verbose:
            print(f"  Iter {it:2d}: f.o. = {m.ObjVal:10.4f}   sobrecargas (MW) = "
                  + ", ".join(f"{sis.c_id[k]}:{sobrecarga[k] * sis.sbase:7.2f}" for k in range(sis.nc)
                              if sobrecarga[k] > tol or sis.nc <= 8)
                  + f"   -> +1 linea en {sis.c_id[k_sel]}")
        n_adic[k_sel] += 1
    else:
        estado_final = "LIMITE_DE_ITERACIONES"

    if verbose and historia and historia[-1].get("estado") == "OPTIMO":
        print(f"  Iter {historia[-1]['iteracion']:2d}: f.o. = {historia[-1]['objetivo']:10.4f}"
              "   -> sin sobrecargas: plan factible")
    return dict(n=n_adic, historia=historia, estado=estado_final,
                tiempo_total_s=time.perf_counter() - t0, criterio=criterio)
