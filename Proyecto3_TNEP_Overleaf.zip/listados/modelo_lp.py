def construir_lp(sis, n_adic, env):
    """Programa lineal de Villasana-Garver para la red con `n_adic` lineas nuevas."""
    m = gp.Model("TNEP_LP_Villasana_Garver", env=env)
    ramas = ramas_activas(sis, n_adic)           # red existente + lineas agregadas
    grado = np.zeros(sis.nb, dtype=int)
    for r in ramas:
        grado[r["de"]] += 1
        grado[r["a"]] += 1

    # Variables: angulos (libres), flujos en ramas (acotados) y sobrecargas
    theta = m.addVars(sis.nb, lb=-GRB.INFINITY, ub=GRB.INFINITY, name="theta")
    for i in range(sis.nb):                       # referencia y barras aisladas
        if i == sis.ref or grado[i] == 0:
            theta[i].lb = theta[i].ub = 0.0
    pf = m.addVars(len(ramas), lb=[-r["pmax"] for r in ramas],
                   ub=[r["pmax"] for r in ramas], name="PF")          # (6)
    abierto = [n_adic[k] < sis.c_nmax[k] for k in range(sis.nc)]
    p_mas = m.addVars(sis.nc, lb=0.0, ub=[GRB.INFINITY if a else 0.0 for a in abierto],
                      name="Pmas")                                     # (7)
    p_menos = m.addVars(sis.nc, lb=0.0, ub=[GRB.INFINITY if a else 0.0 for a in abierto],
                        name="Pmenos")

    # (5) Segunda ley de Kirchhoff en la red: PF = b (theta_i - theta_j)
    for e, r in enumerate(ramas):
        m.addConstr(pf[e] == r["b"] * (theta[r["de"]] - theta[r["a"]]), name=f"KVL_{r['etiqueta']}_{e}")

    # (4) Balance nodal: PG - B theta + K (P+ - P-) = PL
    salida = [gp.LinExpr() for _ in range(sis.nb)]
    for e, r in enumerate(ramas):
        salida[r["de"]] += pf[e]
        salida[r["a"]] -= pf[e]
    inyeccion = [gp.LinExpr() for _ in range(sis.nb)]
    for k in range(sis.nc):          # K: +1 en la barra 'Hasta', -1 en la barra 'Desde'
        inyeccion[sis.c_a[k]] += p_mas[k] - p_menos[k]
        inyeccion[sis.c_de[k]] -= p_mas[k] - p_menos[k]
    for i in range(sis.nb):
        m.addConstr(sis.pg[i] - salida[i] + inyeccion[i] == sis.pl[i],
                    name=f"balance_{sis.barras[i]}")

    # (3) Funcion objetivo: costo de la capacidad faltante en los corredores
    costo_unit = sis.c_costo / sis.c_pmax
    m.setObjective(gp.quicksum(costo_unit[k] * (p_mas[k] + p_menos[k]) for k in range(sis.nc)),
                   GRB.MINIMIZE)
    return m, dict(theta=theta, pf=pf, p_mas=p_mas, p_menos=p_menos, ramas=ramas)
